/*
*/

//#include <iostream>
//using namespace std;
//
//class Myclass {
//private:
//	int num;
//public:
//	void setNum(int n) { num = 0; }
//	void print() const { 
//		cout << "Before: " << num;
//		//num++;
//		const_cast<Myclass*>(this)->num--;
//		cout << "  after: " << num << endl;
//	}
//
//};
//int main() 
//{
//	Myclass obj;
//	obj.setNum(10);
//	obj.print();
//
//	return 0;
//}